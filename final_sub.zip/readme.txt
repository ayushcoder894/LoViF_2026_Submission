runtime per video [s] : 5.0
CPU[1] / GPU[0] : 0
Extra Data [1] / No Extra Data [0] : 1
Other description : FINAL SUBMISSION.
